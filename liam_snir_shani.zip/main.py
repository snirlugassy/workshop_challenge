from model import Model

if __name__ == "__main__":
    reuter_model = Model()
    print(reuter_model.predict("testing_data_ex/"))
